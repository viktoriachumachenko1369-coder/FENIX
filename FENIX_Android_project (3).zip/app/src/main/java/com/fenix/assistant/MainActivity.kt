package com.fenix.assistant

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter

private val Ink = Color(0xFF100D10)
private val Panel = Color(0xFF211820)
private val Wine = Color(0xFF762B45)
private val Gold = Color(0xFFD6B878)
private val Cream = Color(0xFFF5EDE8)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            FenixApp(
                speak = { if (ready) tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "fenix") },
                voices = { tts?.voices?.filter { it.locale.language in listOf("ru", "en") }?.sortedBy { it.name } ?: emptySet() },
                selectVoice = { name -> tts?.voices?.firstOrNull { it.name == name }?.let { tts?.voice = it } }
            )
        }
    }

    override fun onInit(status: Int) { ready = status == TextToSpeech.SUCCESS }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FenixApp(
    speak: (String) -> Unit,
    voices: () -> Set<Voice>,
    selectVoice: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var server by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var selectedVoice by remember { mutableStateOf("") }
    var voiceList by remember { mutableStateOf(emptyList<Voice>()) }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatMessage("Я FENIX. Напиши мне, чтобы начать разговор.", false)) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Wine, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Cream, onSurface = Cream
    )) {
        Scaffold(containerColor = Ink, topBar = {
            TopAppBar(
                title = { Column { Text("FENIX", color = Gold); Text("ТВОЙ ЛИЧНЫЙ ИИ-АССИСТЕНТ", style = MaterialTheme.typography.labelSmall, color = Cream.copy(alpha=.65f)) } },
                actions = { TextButton(onClick = { voiceList = voices().toList(); showSettings = true }) { Text("НАСТРОЙКИ", color = Gold) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
            )
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(14.dp)) {
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(color = if (msg.fromUser) Wine else Panel, shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.widthIn(max = 310.dp).padding(13.dp)) {
                                    Text(if (msg.fromUser) "ТЫ" else "FENIX", color = Gold, style = MaterialTheme.typography.labelSmall)
                                    Spacer(Modifier.height(4.dp))
                                    Text(msg.text, color = Cream)
                                    if (!msg.fromUser) TextButton(onClick = { speak(msg.text) }) { Text("▶ Озвучить", color = Gold) }
                                }
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Напиши сообщение…") }, shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Cream, unfocusedTextColor = Cream, focusedBorderColor = Gold, unfocusedBorderColor = Wine)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(enabled = input.isNotBlank() && !busy, onClick = {
                        val prompt = input.trim()
                        input = ""
                        messages.add(ChatMessage(prompt, true))
                        busy = true
                        scope.launch {
                            val reply = if (server.isBlank()) {
                                "Интерфейс FENIX готов. Чтобы получать ответы ИИ, открой настройки и укажи HTTPS-адрес своего серверного API."
                            } else callServer(server, prompt)
                            messages.add(ChatMessage(reply, false))
                            busy = false
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Wine)) { Text("➤") }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold)
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Настройки FENIX", color = Gold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("HTTPS-адрес твоего серверного API", color = Cream)
                        OutlinedTextField(value = server, onValueChange = { server = it }, placeholder = { Text("https://example.com/chat") })
                        Text("Голос устройства", color = Gold)
                        if (voiceList.isEmpty()) Text("Голоса пока не доступны. Проверь установленные движки синтеза речи Android.")
                        voiceList.take(30).forEach { v ->
                            TextButton(onClick = { selectedVoice = v.name; selectVoice(v.name) }) {
                                Text((if (selectedVoice == v.name) "✓ " else "") + "${v.name} (${v.locale.displayName})", color = Cream)
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Готово", color = Gold) } },
                containerColor = Panel
            )
        }
    }
}

private suspend fun callServer(endpoint: String, prompt: String): String = withContext(Dispatchers.IO) {
    try {
        val url = URL(endpoint)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val escaped = prompt.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
        connection.outputStream.use { OutputStreamWriter(it, Charsets.UTF_8).use { w -> w.write("{\"message\":\"$escaped\"}") } }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        if (code !in 200..299) "Ошибка сервера ($code): $body"
        else Regex("\"answer\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"").find(body)?.groupValues?.get(1)
            ?.replace("\\n", "\n")?.replace("\\\"", "\"")?.replace("\\\\", "\\")
            ?: body
    } catch (e: Exception) { "Не удалось связаться с сервером: ${e.message}" }
}
